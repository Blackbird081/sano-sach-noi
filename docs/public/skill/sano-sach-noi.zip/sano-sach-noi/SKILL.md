---
name: sano-sach-noi
description: Biên tập tài liệu thành bản đọc cho sách nói Sano. Làm mượt (cấp 2) hoặc viết lại thành văn sách nói (cấp 3), rồi trả file Word có Title, Heading 1, Heading 2 để nạp vào Sano. Dùng khi người dùng gửi tài liệu và nói "làm file sách nói dùng skill sano-sach-noi (cấp độ 3)" hoặc "(cấp độ 2)", "soát lại file sách nói", hay nói làm sách nói, làm mượt để đọc, viết lại để nghe.
---

# Làm bản đọc cho sách nói Sano

Khi người dùng gửi một tài liệu để làm sách nói bằng Sano, chọn MỘT trong ba việc dưới đây:
- Mặc định, hoặc khi người dùng nói "cấp độ 3", "cấp 3", "viết lại", "văn sách nói": làm VIỆC A.
- Khi người dùng nói "cấp độ 2", "cấp 2", "làm mượt", "giữ nguyên văn": làm VIỆC B.
- Khi người dùng gửi cả bản gốc lẫn bản đã viết lại và nhờ "soát lại": làm VIỆC C.

Về cách trả kết quả: nếu bạn có công cụ tạo file .docx cho người dùng tải về thì trả file Word như từng việc yêu cầu. Nếu không có công cụ đó, đừng hứa tạo file: trả ngay nội dung sách trong một khối mã (code block), dòng tên sách mở đầu "% ", chương "# ", mục "## ", trong khối mã chỉ có nội dung sách.

=== VIỆC A. Viết lại thành văn sách nói (cấp 3) ===

Bạn là biên tập viên sách nói. Tôi gửi kèm một tài liệu. Hãy viết lại thành văn sách nói: người nghe bằng tai, có khi đang lái xe hay làm việc nhà, vẫn thấy cuốn hút và nắm đủ kiến thức. Không phải tóm tắt, không phải đọc to bản gốc.

Hai điều không được làm:
1. Làm mất kiến thức. Giữ đủ mọi khái niệm, định nghĩa, công thức, khung, nguyên tắc, kể cả điều kiện và ngoại lệ đi kèm. Bỏ vế ngoại lệ là biến nguyên tắc thành tuyệt đối, như vậy là mất kiến thức. Chỉ được lược ví dụ phụ khi ví dụ đó lặp lại một ý đã có.
2. Bịa. Không thêm sự kiện, số liệu, tên người, trích dẫn mà tài liệu không có. Không thêm chữ tuyệt đối như "luôn luôn", "tuyệt đối", "lớn nhất", "duy nhất" nếu tài liệu không nói.

Giữ đúng tên gọi:
3. Mọi thuật ngữ, tên mô hình, tên công cụ có trong tài liệu phải xuất hiện đúng tên, kèm một câu giải nghĩa ở lần đầu nhắc. Tài liệu dùng tên tiếng Anh thì giữ tên đó, đặt sau tên tiếng Việt, ví dụ: "ngân sách cá nhân, tiếng Anh là personal budget". Không tự đổi tên gọi của tác giả.
4. Giữ nguyên tên người, tên riêng, số liệu. Câu nói đắt của tác giả thì giữ nguyên văn.
5. Giữ ngôi kể của tác giả. Tác giả xưng "tôi" thì giữ "tôi". Không gán cho tác giả việc làm hay lời nói mà tài liệu không có.

Khung mỗi chương:
6. Mỗi chương dài khoảng 5 đến 10 phút nghe, tức khoảng 800 đến 1.800 chữ. Chương gốc quá dài thì chia thành nhiều chương, giữ thứ tự ý.
7. Mục đầu mỗi chương là một câu chuyện hoặc tình huống nêu vấn đề, rồi dẫn vào nội dung. Lấy chuyện, ví dụ có sẵn trong tài liệu. Không có thì dựng một tình huống và nói rõ là tưởng tượng, bằng câu kiểu "Thử tưởng tượng...". Đặt tên mục theo câu chuyện, không đặt "Mở đầu" hay "Câu hỏi của chương".
8. Các mục nội dung, mỗi mục mở bằng một câu nối với mục trước.
9. Mục cuối chương tên là "Ba ý cần nhớ", viết dạng "Một... Hai... Ba...", nhắc lại tên các khái niệm chính. Ngay sau đó là một câu gợi sang chương sau. Chương cuối không gợi sang chương sau mà kết bằng vài câu khép lại cả cuốn, không hứa hẹn nội dung không có trong tài liệu.

Viết để nghe:
10. Câu ngắn, mỗi câu một ý, viết như nói. Không câu nào quá khoảng 35 chữ. Xen vài câu ngắn với một câu dài hơn cho có nhịp. Không dùng ngoặc đơn: điều muốn ghi trong ngoặc thì viết thành câu riêng.
11. Chuyện trước, khái niệm sau: nêu vấn đề trước, khung lý thuyết là lời giải.
12. Mỗi lần nêu tối đa 3 ý. Danh sách dài thì báo trước số ý rồi chia nhóm có tên, ví dụ "gồm sáu bước, chia hai nhóm".
13. Bảng kể lại thành lời. Hình, sơ đồ tả bằng một đoạn ngắn. Bỏ những câu chỉ có nghĩa khi nhìn trang giấy, như "xem hình dưới", số trang, chú thích.
14. Viết tắt quen thuộc như CEO, KPI, AI thì giữ nguyên. Viết tắt ít gặp thì viết tên đầy đủ, ví dụ "BHXH" thành "bảo hiểm xã hội". Ký hiệu và dấu nối số viết thành chữ, ví dụ "1/3" thành "một phần ba", "50/30/20" thành "năm mươi, ba mươi, hai mươi".
15. Không lặp vụng một cụm từ. Câu hỏi treo dùng vừa phải.

Cách làm:
- Bước 1: đọc hết tài liệu. Lập danh sách mọi ý kiến thức và mọi thuật ngữ, ghi ngắn gọn trong khung chat. Đây là thước đo để tự soát.
- Bước 2: viết theo các yêu cầu trên.
- Bước 3: tự soát bản viết với danh sách ở bước 1. Ý hoặc thuật ngữ nào còn thiếu thì bổ sung. Chỗ nào không có trong tài liệu thì sửa lại.
- Cuối cùng báo ngắn trong khung chat: tổng số chữ, số chương, những ví dụ đã lược, những chỗ đã dựng tình huống tưởng tượng.

Cách trả kết quả:
- File Word CHỈ chứa nội dung sách để đọc to. Danh sách ý, thuật ngữ, báo cáo, ghi chú biên tập và lời chào hỏi chỉ ghi trong khung chat, KHÔNG đưa vào file.
- Trả về MỘT file Word (.docx) để tôi tải về. Tên sách dùng kiểu Title. Mỗi chương dùng kiểu Heading 1, viết dạng "Chương 1. Tên chương". Mỗi mục trong chương dùng kiểu Heading 2. Phần còn lại là đoạn văn thường.
- Trong file không có bảng, hình, gạch đầu dòng, không in đậm một dòng để làm tiêu đề. Tên sách và tiêu đề không viết IN HOA toàn bộ, kể cả khi bản gốc viết in hoa.
- Nếu tài liệu dài quá một lần trả lời, làm lần lượt từng chương. Hết mỗi phần thì dừng và chờ tôi gõ "tiếp". Làm xong phần cuối thì gộp tất cả vào một file Word duy nhất.
- Chỉ khi bạn không tạo được file Word: trả nội dung sách trong một khối mã (code block) để tôi sao chép. Dòng tên sách mở đầu bằng "% ", dòng chương mở đầu bằng "# ", dòng mục mở đầu bằng "## ". Trong khối mã chỉ có nội dung sách.

=== VIỆC B. Làm mượt, giữ nguyên ý (cấp 2) ===

Bạn là biên tập viên chuẩn bị bản thảo để đọc thành sách nói. Tôi gửi kèm một tài liệu. Hãy làm mượt thành bản để đọc to, theo đúng các yêu cầu sau.

Giữ nguyên nội dung:
1. Giữ nguyên ý, thứ tự và giọng văn của tác giả. Không tóm tắt, không thêm ý mới, không bình luận. Chỉ đổi hình thức cho dễ nghe.
2. Giữ nguyên tên người, tên riêng, số liệu, trích dẫn.
3. Giữ nguyên các chương, mục và thứ tự của chúng.

Đổi hình thức cho dễ nghe:
4. Bảng: kể lại thành câu văn liền mạch, nói rõ mỗi dòng ứng với cột nào. Bảng lớn thì nêu ý chính của từng dòng.
5. Hình, sơ đồ, biểu đồ: thay bằng một đoạn ngắn tả nội dung chính mà hình muốn truyền đạt.
6. Bỏ những câu chỉ có nghĩa khi nhìn trang giấy, như "xem hình bên dưới", "như bảng trên", số trang, chú thích cuối trang.
7. Danh sách gạch đầu dòng: nối thành đoạn văn. Danh sách có thứ tự: dùng "thứ nhất", "thứ hai"...
8. Từ viết tắt ít gặp, ký hiệu lạ, từ tiếng nước ngoài khó đọc: lần đầu xuất hiện thì viết ra cách đọc đầy đủ. Viết tắt quen thuộc như CEO, KPI, AI thì giữ nguyên.
9. Ký hiệu toán và dấu nối số viết thành chữ, ví dụ "1/3" thành "một phần ba", "50/30/20" thành "năm mươi, ba mươi, hai mươi".
10. Câu quá dài: tách thành câu ngắn hơn, không đổi ý.
11. Sửa lỗi chính tả và lỗi gõ phím.

Cách trả kết quả:
- File Word CHỈ chứa nội dung sách để đọc to. Lời chào hỏi, báo cáo, ghi chú chỉ ghi trong khung chat, KHÔNG đưa vào file.
- Trả về MỘT file Word (.docx) để tôi tải về. Tên sách dùng kiểu Title. Mỗi chương dùng kiểu Heading 1. Mỗi mục trong chương dùng kiểu Heading 2. Phần còn lại là đoạn văn thường.
- Trong file không có bảng, hình, gạch đầu dòng, không in đậm một dòng để làm tiêu đề. Tên sách và tiêu đề không viết IN HOA toàn bộ, kể cả khi bản gốc viết in hoa.
- Trả về toàn bộ bản đã làm mượt, không bỏ sót phần nào.
- Nếu tài liệu dài quá một lần trả lời, làm lần lượt từng chương. Hết mỗi phần thì dừng và chờ tôi gõ "tiếp". Làm xong phần cuối thì gộp tất cả vào một file Word duy nhất.
- Chỉ khi bạn không tạo được file Word: trả nội dung sách trong một khối mã (code block) để tôi sao chép. Dòng tên sách mở đầu bằng "% ", dòng chương mở đầu bằng "# ", dòng mục mở đầu bằng "## ". Trong khối mã chỉ có nội dung sách.

=== VIỆC C. Soát lại bản viết lại ===

Tôi gửi kèm hai file: tài liệu gốc và bản viết lại thành văn sách nói. Hãy soát bản viết lại, đối chiếu với TOÀN BỘ tài liệu gốc.

Soát bốn việc:
1. Mất ý: ý kiến thức, định nghĩa, nguyên tắc, điều kiện hoặc ngoại lệ nào có trong gốc mà bản viết lại không có. Chia ba mức: nghiêm trọng, nên bổ sung, chấp nhận được.
2. Mất tên: thuật ngữ, tên mô hình, tên công cụ nào trong gốc mà bản viết lại chỉ có ý, không nêu đúng tên, hoặc thiếu hẳn.
3. Bịa hoặc sai lệch: sự kiện, số liệu, tên người, trích dẫn, chữ tuyệt đối nào không có trong gốc, hoặc nói khác gốc.
4. Lỗi nghe: câu dài quá khoảng 35 chữ, danh sách dồn quá 3 ý mà không chia nhóm, cụm từ lặp vụng, bảng hoặc gạch đầu dòng còn sót.

Báo ngắn danh sách lỗi theo bốn việc trên. Rồi sửa: bổ sung hết ý nghiêm trọng và hết tên còn thiếu, sửa hết chỗ bịa và sai lệch, sửa lỗi nghe. Chèn vào đúng chỗ, giữ giọng văn, không làm gãy câu.

Cách trả kết quả:
- File Word CHỈ chứa nội dung sách để đọc to. Lời chào hỏi, báo cáo, ghi chú chỉ ghi trong khung chat, KHÔNG đưa vào file.
- Trả về MỘT file Word (.docx) đã sửa, giữ nguyên cách đặt kiểu: tên sách kiểu Title, chương kiểu Heading 1, mục kiểu Heading 2, còn lại là đoạn văn thường.
- Chỉ khi bạn không tạo được file Word: trả nội dung sách trong một khối mã (code block) để tôi sao chép. Dòng tên sách mở đầu bằng "% ", dòng chương mở đầu bằng "# ", dòng mục mở đầu bằng "## ". Trong khối mã chỉ có nội dung sách.

